# Problema Barbeiro Dorminhoco
import threading
import time
import random
class BarberShop:
    def __init__(self, num_chairs):
        self.num_chairs = num_chairs
        self.customers = 0
        self.barber_sleeping = True
        self.lock = threading.Lock()
        self.barber_condition = threading.Condition(self.lock)
        self.customer_condition = threading.Condition(self.lock)

    def barber(self):
        while True:
            with self.lock:
                if self.customers == 0:
                    print("Barber is sleeping.")
                    self.barber_sleeping = True
                    self.barber_condition.wait()
                self.customers -= 1
                print("Barber is cutting hair.")
            time.sleep(random.uniform(0.1, 1))

    def customer(self):
        while True:
            with self.lock:
                if self.customers < self.num_chairs:
                    self.customers += 1
                    print("Customer arrived.")
                    if self.barber_sleeping:
                        print("Waking up barber.")
                        self.barber_condition.notify()
                        self.barber_sleeping = False
                    self.customer_condition.wait()

def barber_shop_simulation():
    barber_shop = BarberShop(3) 
    barber_thread = threading.Thread(target=barber_shop.barber)
    customer_threads = [threading.Thread(target=barber_shop.customer) for _ in range(5)]

    barber_thread.start()
    for thread in customer_threads:
        thread.start()

    barber_thread.join()
    for thread in customer_threads:
        thread.join()
barber_shop_simulation()