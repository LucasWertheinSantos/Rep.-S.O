# Problema Leitores/Escritores
import threading
import time
import random
class ReaderWriter:
    def __init__(self):
        self.readers = 0
        self.lock = threading.Lock()
        self.resource = 0

    def read(self):
        with self.lock:
            self.readers += 1
            if self.readers == 1:
                self.resource += 1
            print(f"Reader reads: {self.resource}")

    def release_read(self):
        with self.lock:
            self.readers -= 1
            if self.readers == 0:
                self.resource -= 1

    def write(self):
        with self.lock:
            self.resource += 1
            print(f"Writer writes: {self.resource}")

    def release_write(self):
        with self.lock:
            self.resource -= 1

def reader(reader_writer):
    while True:
        time.sleep(random.uniform(0.1, 1))
        reader_writer.read()
        time.sleep(random.uniform(0.1, 1))
        reader_writer.release_read()

def writer(reader_writer):
    while True:
        time.sleep(random.uniform(0.1, 1))
        reader_writer.write()
        time.sleep(random.uniform(0.1, 1))
        reader_writer.release_write()
rw = ReaderWriter()
reader_threads = [threading.Thread(target=reader, args=(rw,)) for _ in range(3)]
writer_threads = [threading.Thread(target=writer, args=(rw,)) for _ in range(2)]
for thread in reader_threads:
    thread.start()
for thread in writer_threads:
    thread.start()
for thread in reader_threads:
    thread.join()
for thread in writer_threads:
    thread.join()
