# Problema Produtor/Consumidor
import threading
import time
import random
class Buffer:
    def __init__(self, size):
        self.size = size
        self.buffer = []
        self.lock = threading.Condition()

    def produce(self, item):
        with self.lock:
            while len(self.buffer) >= self.size:
                self.lock.wait()
            self.buffer.append(item)
            print(f"Produced {item}. Buffer: {self.buffer}")
            self.lock.notify_all()

    def consume(self):
        with self.lock:
            while not self.buffer:
                self.lock.wait()
            item = self.buffer.pop(0)
            print(f"Consumed {item}. Buffer: {self.buffer}")
            self.lock.notify_all()
            return item

def producer(buffer):
    for i in range(5):
        time.sleep(random.uniform(0.1, 1))
        buffer.produce(i)

def consumer(buffer):
    for i in range(5):
        time.sleep(random.uniform(0.1, 1))
        item = buffer.consume()

buffer = Buffer(3) # Buffer de tamanho 3
prod_thread = threading.Thread(target=producer, args=(buffer,))
cons_thread = threading.Thread(target=consumer, args=(buffer,))
prod_thread.start()
cons_thread.start()
prod_thread.join()
cons_thread.join()