# Problema Jantar dos Filósofos
import threading
import time
import random
class DiningPhilosophers:
    def __init__(self):
        self.forks = [threading.Lock() for _ in range(5)]
        self.philosophers = [threading.Thread(target=self.dine, args=(i,)) for i in range(5)]

    def dine(self, philosopher_id):
        left_fork = self.forks[philosopher_id]
        right_fork = self.forks[(philosopher_id + 1) % 5]
        if philosopher_id == 0:
            left_fork, right_fork = right_fork, left_fork # deadlock
        while True:
            with left_fork:
                with right_fork:
                    print(f"Philosopher {philosopher_id} is eating.")
                    time.sleep(random.uniform(0.1, 1))

    def start_dining(self):
        for philosopher in self.philosophers:
            philosopher.start()
        for philosopher in self.philosophers:
            philosopher.join()
dining_philosophers = DiningPhilosophers()
dining_philosophers.start_dining()